﻿namespace Lab_7_DelegatesAndEvents
{
    public interface IEnumerable
    {
    }
}