﻿using System;
using System.Collections.Generic;

namespace Lab_7_DelegatesAndEvents
{

    public enum StatusType
    {
        FRESHMEN,
        SOPHOMORE,
        JUNIOR,
        SENIOR
    }

    public class StudentInfo
    {
        public StudentInfo(string name, DateTime dob, string major, bool isRegistered, StatusType status)
        {
            Name = name;
            DOB = dob;
            Major = major;
            IsRegistered = isRegistered;
            Status = status;
        }

        private string Name { get; }
        private DateTime DOB { get; }
        private string Major { get; }
        private bool IsRegistered { get; set; }
        private StatusType Status { get; }

        public override string ToString()
        {
            return "Name:" + Name + " DOB:" + DOB.ToString("d") + " Major:" + Major + " Registered:" + IsRegistered + " Status:" + Status;
        }

    }

    public class StudentEventArgs : EventArgs
    {
        public StudentEventArgs(StudentInfo s) => S = s;
        public StudentInfo S { get; }
    }

    public class StudentHandler
    {
        public event EventHandler<StudentEventArgs> NewStudentInfo;

        public void NewStudentArrived(StudentInfo student)
        {
            Console.WriteLine($"A new student has arrived => {student}");

            NewStudentInfo?.Invoke(this, new StudentEventArgs(student));
        }
    }

    public class Registrar
    { 
        private List<StudentInfo> _students = new List<StudentInfo>();

        public Registrar(List<StudentInfo> students) => _students = students;

        public void NewStudentIsHere(object sender, StudentEventArgs e)
        {
            Console.WriteLine("A list of student(s) => "+ string.Join("\t", _students));
            //_students.ForEach(Console.WriteLine);
            Console.WriteLine($"A new student is here => {e.S}"); 
        }
    }


    class MainClass
    {
        private static void SleepFunc()
        {
            Random randomN = new Random();
            int seconds;
            seconds = randomN.Next(100, 3000);
            System.Threading.Thread.Sleep(seconds);
        }

        public static void Main(string[] args)
        {
            
         
            DateTime s1DOB = new DateTime(2000, 2, 28);
            DateTime s2DOB = new DateTime(1992, 12, 3);
            DateTime s3DOB = new DateTime(1997, 7, 15);

            List<StudentInfo> studentList = new List<StudentInfo>();
            List<StudentInfo> studentList2 = new List<StudentInfo>();
            var student = new StudentInfo("Heeju Park", s1DOB, "Computer Programming", true, StatusType.SENIOR);
            var student2 = new StudentInfo("Susan Morgan", s2DOB, "Accounting", true, StatusType.JUNIOR);
            var student3 = new StudentInfo("Vitoria Thomson", s3DOB, "Marketing", true, StatusType.FRESHMEN);



            //Put the thread to sleep
            SleepFunc();

            StudentHandler newStudent = new StudentHandler();
         
            studentList.Add(student);
            var list1 = new Registrar(studentList);
            newStudent.NewStudentInfo += list1.NewStudentIsHere;
            newStudent.NewStudentArrived(student2);
            Console.WriteLine("\n");
            SleepFunc();

            studentList2.Add(student2);
            var list2 = new Registrar(studentList2);
            newStudent.NewStudentInfo += list2.NewStudentIsHere;
            newStudent.NewStudentArrived(student3);
            Console.WriteLine("\n");
            SleepFunc();

            newStudent.NewStudentInfo -= list1.NewStudentIsHere;
            newStudent.NewStudentArrived(student);

        }
    }
}
